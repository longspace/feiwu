<template>
    <div class="containerbox">
        The page was not fund !
    </div>

</template>

<script>
export default {
name: '404',
    data() {
        return {};
    },
    methods: {
        
    },
    mounted(){

    }
}
</script>

<style scoped>
.containerbox{ text-align: center; padding-top: 150px; font-size: 20px;}
</style>
