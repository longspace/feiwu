<template>
  <div>商品分类</div>
</template>

<script>
</script>

<style>
</style>
