<template>
  <div>
    用户注册
  </div>
</template>
<script>
  export default {
    name:'',
    data() {
      return {

      };
    },
    components:{

    },
    methods:{

    },
    mounted(){

    }
  };
</script>
<style lang="scss">

</style>
<style scoped lang="scss" rel="stylesheet/scss">

</style>
