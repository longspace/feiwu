<template>
  <div style="text-align: center; padding-top: 200px;">
    <div>工业废物数字化交易平台V1.0</div>
    <div>
      <router-link to="login">登录</router-link> |
      <router-link to="reg">注册</router-link>
    </div>

  </div>
</template>
<script>
  export default {
      name:'',
      data() {
        return {
          
        };
      },
      methods:{
        init(){
          
        }
      },
      mounted(){
        this.init();
      }
  };
</script>
<style lang="scss">

</style>
<style scoped lang="scss" rel="stylesheet/scss">

</style>
