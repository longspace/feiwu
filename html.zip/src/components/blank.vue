<template>
  <div>

  </div>
</template>
<script>
  export default {
    name:'',
    data() {
      return {

      };
    },
    components:{

    },
    methods:{

    },
    mounted(){

    }
  };
</script>
<style lang="scss">

</style>
<style scoped lang="scss" rel="stylesheet/scss">

</style>
